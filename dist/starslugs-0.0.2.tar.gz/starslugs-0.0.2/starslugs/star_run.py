import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import astropy


# read in csv data
data = pd.read_csv('../data/exoplanet_archive_2026_06_22.csv', skiprows=28)


class Distance():
    def __init__(self, system1, system2):

        self.ra1 = system1.ra
        self.ra2 = system2.ra
        self.dec1 = system1.dec
        self.dec2 = system2.dec
        self.d1 = system1.distance
        self.d2 = system2.distance
        self.theta = self.angular_dist()
        self.distance= self.physical_dist()
    
    def angular_dist(self):
        '''
        Calculates the angular distance (great circle portion) between 2 RA/Dec coordinate pairs inside celestial sphere.
        Args:
            ra1: RA of 1st object [deg.]
            dec1: Dec of 1st object [deg.]
            ra2: RA of 2nd object [deg.]
            dec2: RA of 2nd object [deg.]
        Output:
            theta: angular distance between 2 objects [deg.]
        '''
        
        ra1_rad = np.radians(self.ra1)
        dec1_rad = np.radians(self.dec1)
        ra2_rad = np.radians(self.ra2)
        dec2_rad = np.radians(self.dec2)
        
        a = (np.sin(abs(dec1_rad-dec2_rad)/2))**2
        b = np.cos(dec1_rad)*np.cos(dec2_rad)*((np.sin(abs(ra1_rad-ra2_rad)/2))**2)
        
        theta_rad = 2*np.arcsin(np.sqrt(a+b))
                
        return np.degrees(theta_rad)
    
    def physical_dist(self):
        '''
        Uses the physical and angular distances between 2 objects to calculate (3-D) distance between them with law of cosines.
        Args:
            d1: physical distance to 1st object [pc]
            d2: physical distance to 2nd object [pc]
            theta: angular distance (great circle) between 2 objects on celestial sphere [deg]
        Returns:
            D: physical distance from object 1 to object 2 [pc]
        '''

        D_squared = self.d1**2 + self.d2**2 - 2*self.d1*self.d2*np.cos(self.theta)

        return np.sqrt(D_squared)


class StarSystem():
    def __init__(self, csv_data, sys_name):

        self.csv_data = csv_data # Reading the csv data into a pandas dataframe
        self.sys_name = sys_name # hostname
        self.distance = None # sy_dist
        self.ra =  None # ra
        self.dec = None # dec
        self.star_teff =  None # st_teff
        self.pl_num = None # sy_pnum
        self.star_num = None # sy_snum
        self.get_info()
    
    def clean_data(self) -> pd.DataFrame:
        """
        Clean the data for the system
        """
        mask  = self.csv_data['st_teff'].isna() | self.csv_data['sy_dist'].isna()
        self.csv_data = self.csv_data[~mask]
        return self.csv_data
    
    def get_row(self):
        """
        csv_data: assuming this is already read into a pd dataframe
        """
        self.clean_data()
        obj_rows = self.csv_data[self.csv_data['hostname'] == self.sys_name] # Getting the row for the system

        if len(obj_rows) > 1:
            obj_rows = obj_rows.iloc[0]

        #print('distance = '+str(obj_rows['sy_dist']))
        return obj_rows
    
    def get_info(self):
        """
        Get the information for the system
        """
        obj = self.get_row()
        self.distance = obj['sy_dist']
        self.ra = obj['ra']
        self.dec = obj['dec']
        self.star_teff = obj['st_teff']
        self.pl_num = obj['sy_pnum']
        self.star_num = obj['sy_snum']

        return
    
    def print_info(self):
        """
        Print the information for the system
        """
        
        row_name = [self.sys_name]
        col_name = ['RA [deg]', 'Dec [deg]', 'Distance [pc]', 'Teff [k]', '# Planets', '# Stars']
        table_data = [[self.ra, self.dec, self.distance, self.star_teff, self.pl_num, self.star_num]]
        my_table = plt.table(cellText=table_data, rowLabels=row_name, colLabels=col_name, loc='center', cellLoc='center')
        plt.axis('off')
        # Increase cell size (width factor, height factor)
        my_table.scale(1, 1.5)

        #plt.show()

        return


def print_info_systems(systems_list):
    """print_info_systems

    Print the information for two systems

    Args:
        a (array): I'm just testing things
    
    Returns:
        float: Another test
    """
    row_name = []
    for i in range(len(systems_list)):
        row_name.append(systems_list[i].sys_name)
    col_name = ['RA [deg]', 'Dec [deg]', 'Distance [pc]', 'Teff [k]', '# Planets', '# Stars']

    table_data = []
    for i in range(len(systems_list)):
        table_data.append([round(systems_list[i].ra,3), round(systems_list[i].dec,3), round(systems_list[i].distance,3), systems_list[i].star_teff, systems_list[i].pl_num, systems_list[i].star_num])
    
    fig, ax = plt.subplots(figsize=(8, 3 + 0.7 * len(table_data)), dpi=200)  # Increase figure size and resolution
    ax.axis('off')
    my_table = ax.table(cellText=table_data, rowLabels=row_name, colLabels=col_name, loc='center', cellLoc='center')

    # Enhance table aesthetics for higher quality
    my_table.auto_set_font_size(False)
    my_table.set_fontsize(8)
    my_table.scale(1.2, 1.8)

    plt.tight_layout(pad=2)
    #plt.savefig("star.png", dpi=300, bbox_inches='tight', transparent=True)  # Save with higher DPI and cleaner layout
    #plt.close(fig)
    #plt.show()

    return my_table, fig